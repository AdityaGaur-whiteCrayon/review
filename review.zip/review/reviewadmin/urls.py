from django.urls import path
from . import views
urlpatterns = [
path('',views.index,name='index'),
path('addcompany',views.addcompany,name='addcompany'),
#path('dashboard',views.dashboard,name='dashboard')



]