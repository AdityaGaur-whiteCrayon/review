from django.http import request
from django.shortcuts import render,redirect
from userapp.models import  Register, Review,Company,Regadmin
 
# Create your views here.
def index(request):
        if request.session.has_key("aid"):
                data = Regadmin.objects.get(pk=request.session["aid"])
                return render(request,"reviewadmin/index.html",{'res':data})
        else:
                #return redirect("/") 
                return redirect(request,"/")

def addcompany(request):
        if request.method=="POST":
                if(Company.objects.filter(companies=request.POST["txtcompany"]).count()==0):
                        obj =  Company(companies=request.POST["txtcompany"])
                        obj.save()
                        return render(request,"reviewadmin/addcompany.html",{"msg":'company added'})
                else:
                        return render(request,"reviewadmin/addcompany.html",{'msg':" You have already provided review to this company"})
			
        return render(request,"reviewadmin/addcompany.html")

def logout(request):
	del request.session['aid']
	return redirect('/')