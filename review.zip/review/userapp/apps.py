from django.apps import AppConfig



    #default_auto_field = 'django.db.models.BigAutoField'
 
class UserappConfig(AppConfig):
    name = 'userapp'