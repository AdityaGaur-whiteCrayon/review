from django.contrib import admin
from .models import Register,Review,Company,Regadmin
admin.site.register(Register)
admin.site.register(Review)
admin.site.register(Company)
admin.site.register(Regadmin)