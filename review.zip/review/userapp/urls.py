from django.urls import path

from . import views
from reviewadmin.views import index

urlpatterns = [
    path('login', views.login, name='login'),
    path('edituser',views.edituser,name='edituser'),
    path('register', views.register, name='register'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('logout',views.logout,name='logout'),
    path('managereview',views.managereview,name='managereview'),
    path('<int:id>/',views.editreview,name='editreview'),
    #path('editreview',views.editreview,name='editreview'),
    path('deletereview',views.deletereview,name='deletereview'),
    path('', views.home, name='home'),
    path('',index),
]