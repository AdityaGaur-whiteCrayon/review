from django.db import models
from safedelete.models import SafeDeleteModel
from safedelete.models import SOFT_DELETE

#class Ratings(SafeDeleteModel):
#	_safedelete_policy =  SOFT_DELETE
#	ratings = models.IntegerField()
#	def __str__(self):
#		return str(self.ratings)

class Company(SafeDeleteModel):
	_safedelete_policy =SOFT_DELETE
	companies = models.CharField(max_length=100)
	def __str__(self):
		return self.companies 

class Register(SafeDeleteModel):
	_safedelete_policy = SOFT_DELETE
	emailid = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	mobile = models.CharField(max_length=50)
	fullname = models.CharField(max_length=50,default='')
	createdate=models.DateTimeField()
	def __str__(self):
		return "Email id is "+self.emailid + " Password "+self.password + " Mobile no is "+self.mobile + " fullname is "+ self.fullname + " Date is "+ str(self.createdate)

class Review(SafeDeleteModel):
	_safedelete_policy = SOFT_DELETE
	register=models.ForeignKey(Register,on_delete=models.CASCADE)
	#company = models.ForeignKey(Company,models.CASCADE,null=True)
	company=models.CharField(max_length=50,default='')
	rating=models.CharField(max_length=10,default='')
	reviewdesc=models.CharField(max_length=50)
	reviewdate=models.DateTimeField()
	def __str__(self):
		return "register to "+str(self.register )+ " company "+self.company +" rating is "+self.rating + " DESCRIPTION "+ self.reviewdesc + " Date is "+ str(self.reviewdate)
class Regadmin(models.Model):
	emailid = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	createdate=models.DateTimeField()
	def __str__(self):
		return "Email id is "+self.emailid + " Password "+self.password +" Date is "+ str(self.createdate)
