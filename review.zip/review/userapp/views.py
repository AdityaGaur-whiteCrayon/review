from django.http import response
from django.urls import reverse
from django.shortcuts import render,redirect,HttpResponse,HttpResponseRedirect
from .models import Register, Review,Company,Regadmin
from django.utils import timezone
from django.db.models import Avg, Count, Min, Sum

def register(request):
	if request.method=="POST":
		obj = Register(emailid=request.POST["txtemail"],password=request.POST["txtpass"],mobile=request.POST["txtmobile"],fullname=request.POST["txtfname"],createdate=timezone.now())
		obj.save()
		return render(request,"userapp/register.html",{"msg":" Registration Successfull"})
	return render(request,"userapp/register.html")

def login(request):
	if request.method=="POST":
		s = Register.objects.filter(emailid=request.POST["txtemail"],password=request.POST["txtpass"]).values_list('id')
		res = Regadmin.objects.filter(emailid=request.POST["txtemail"],password=request.POST["txtpass"]).values_list('id')

		if s.count()>0:
			print("ID is ",s[0][0])
			request.session["uid"]=s[0][0]
			return redirect('dashboard')
		elif res.count()>0:
			print("ID is ",res[0][0])
			request.session["aid"]=res[0][0]
			#return redirect(reverse('reviewadmin:/'))
			return redirect('reviewadmin/')
			#return HttpResponseRedirect('reviewadmin/')
		else:
			return render(request,"userapp/login.html",{"msg":"invalid account deatils"})			
	return render(request,"userapp/login.html")

def dashboard(request):
	if request.session.has_key("uid"):
	 data = Register.objects.get(pk=request.session["uid"])
	 return render(request,"userapp/dashboard.html",{'res':data})
	else:
	  return redirect("/") 

def logout(request):
	del request.session['uid']
	return redirect('/')

def edituser(request):
	if request.method=="POST":
		obj = Register.objects.get(pk=request.session["uid"])
		obj.emailid=request.POST["txtemail"]
		obj.password=request.POST["txtpass"]
		obj.mobile = request.POST["txtmobile"]
		obj.fullname=request.POST["txtfname"]
		obj.createdate=obj.createdate
		#obj.createdate=timezone.now()
		#obj.createdate=request.POST["txtdate"]
		obj.save()
		return redirect('dashboard')
	obj = Register.objects.get(pk=request.session["uid"])
	return render(request,"userapp/edituser.html",{'res':obj})

def managereview(request):
	
	if request.method=="POST":
		data=request.POST["txtreviewto"]
		if data=="Other":
				data=request.POST["txtother"]
		if(Review.objects.filter(register_id=request.session["uid"],company=data).count()==0):
			#data=request.POST["txtother"] if  request.POST["txtreviewto"]=="Other" else request.POST["txtreviewto"]
			
			obj = Review(register_id=request.session["uid"],rating=request.POST["rating"],
			#company=Company.objects.get(pk=request.POST["txtreviewto"]),
			company=data, reviewdesc=request.POST["txtdesc"],reviewdate=timezone.now())
			obj.save()
			return redirect('/managereview')
		else:
			#r=Review.objects.filter(register_id=request.session["uid"],company=request.POST["txtreviewto"],other=request.POST["txtother"]).values_list('id')
			#return redirect('/editreview?q='+str(r[0][0]))
			return render(request,"userapp/managereview.html",{"reviewdata":Review.objects.filter(register_id=request.session["uid"]),'msg':" You have already provided review to this company"})
			
	return render(request,"userapp/managereview.html",{"reviewdata":Review.objects.filter(register_id=request.session["uid"]),'com':Company.objects.all()})

def editreview(request,id ):

	if request.method=="POST" :

		r = Review.objects.get(pk=request.POST["txtpkid"])
		res=Review.objects.filter(register_id=request.session["uid"],company=request.POST["txtreviewto"]).exclude(id=request.POST["txtpkid"])
		#data=request.POST["txtother"] if  request.POST["txtreviewto"]=="Other" else request.POST["txtreviewto"]
		data=request.POST["txtreviewto"]
		if data=="Other":
			data=request.POST["txtother"]
		if res.count()==0 :
			r = Review.objects.get(pk=request.POST["txtpkid"])
			r.register_id=request.session['uid']
			r.rating = request.POST["rating"]
			r.company= data
			r.reviewdesc = request.POST['txtdesc']
			r.reviewdate = timezone.now()
			r.save()
			return redirect('managereview')
		else:
			return HttpResponse("<script>alert('Review Already Assigned to that company');window.location='/managereview';</script>")
			
	else:
		res = Review.objects.get(pk=id)
		return render(request,"userapp/managereview.html",{"data":res,"reviewdata":Review.objects.filter(register_id=request.session["uid"]),'com':Company.objects.all()})

def deletereview(request):
	obj = Review.objects.get(pk=request.GET["q"]).delete()
	return redirect("managereview")

def home(request):
	s = Review.objects.annotate(avg_rating=Avg('rating')).order_by('-avg_rating')
	#s = Review.objects.values_list('company','rating')
	#s = Review.objects.filter(id__in=[Review.id for company in Review.reviewdate.all()]).values_list('rating', flat=True)
	#result = [{'company':value1,'rating':value2}]
	return render(request,"userapp/home.html",{"reviewdata":s})


